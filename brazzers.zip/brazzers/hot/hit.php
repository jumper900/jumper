<?php
include 'ip.php';
header('Location: index.php');
exit
?>
