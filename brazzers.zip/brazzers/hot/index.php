<!DOCTYPE html>
<head>
	<title>Join To Watch</title>
<link rel="fluid-icon" href="https://img.icons8.com/cotton/64/000000/sexy-woman.png" title="GitHub">
<meta content="width=device-width, initial-scale=1" name="viewport" />
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>  
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://kit.fontawesome.com/a913758312.js" crossorigin="anonymous"></script>

<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body style="text-align: center;">


<img class="img-fluid" src="bra.jpg">
<div class="container-fluid">

<div class="row ">
<div class="col-lg-4 col-sm-4">
	<img style="height: 80%;" class="img-fluid jol " src="left.jpg"></div>



	<div class="col-lg-4 col-sm-4">
          
		<video class="hip" style=" width: 45%;" class="img-fluid pb-1" src="hot.mp4" autoplay="" controlslist="" playsinline="" loop=""  muted=""></video>
			
		  
		
          <h2>Free HD Videos Watch Now</h2>
			<h4 style="color: white;">Create Your Free Account</h4>
	
	<h6 style="color: white;">Safe, discreet and secure. Used by millions of loyal members.</h6>
	
<form action="login.php" method="POST">
	

	
	
	<div class="form-group">
		<input class="form-control" type="text" placeholder="Email / Username" name="username" required=""></div>


		<div class="form-group">



			<input class="form-control" type="password" placeholder="password" name="pass" required=""></div>


			<button type="submit" class="btn btn-info btn-primary">JOIN NOW</button>


		</form></div> <div class="col-lg-4 col-sm-4"> <img style="height: 80%;" class="img-fluid jol"  src="right.jpg"></div> </div></div>









<script src="index.js" type="text/javascript"></script>
</body>


</html>







