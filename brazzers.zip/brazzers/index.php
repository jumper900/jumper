<!DOCTYPE html>
<head>
	<title>JOIN TO WATCH</title>

	<link rel="fluid-icon" href="https://img.icons8.com/cotton/64/000000/sexy-woman.png" title="GitHub">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body style="text-align: center;" öncontextmenu="return false">
	<img style="width: 90%;" src="bra.jpg">
	
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-3 col-md-4 col-sm-6">
			<img src="img/ass.jpg" class="img-fluid pb-1 "> </div>
			
			
			<div class="col-lg-3 col-md-4 col-sm-6">
			<img src="img/cia.jpg" class="img-fluid pb-1"> </div>
			<div class="col-lg-3 col-md-4 col-sm-6">
			<img  src="img/cum.jpg" class="img-fluid pb-1 "> </div>
			<div class="col-lg-3 col-md-4 col-sm-6">
			<a href="hot/index.php"><video class="img-fluid pb-1" src="sec.mp4" autoplay="" controlslist="" playsinline="" loop=""  muted=""></video></a></div>
			
		

			<div class="col-lg-3 col-md-4 col-sm-6">
			<a href="hot/index.php"><video class="img-fluid pb-1 bol" src="sea.mp4" autoplay="" controlslist="" playsinline="" loop=""  muted=""></video></a></div>
			<div class="col-lg-3 col-md-4 col-sm-6">
			<img style="" src="img/tim.jpg" class="img-fluid pb-1"> </div>
			<div class="col-lg-3 col-md-4 col-sm-6">
			<img class="pill" src="img/hum.jpg" class="img-fluid pb-1"> </div>
			<div class="col-lg-3 col-md-4 col-sm-6">
			<img class="till"  src="img/umm.jpg" class="img-fluid pb-1"> </div>
			
			
			
			<div class="col-lg-3 col-md-4 col-sm-6">
			<img  src="img/sin.jpg" class="img-fluid pb-1 jam"> </div>
			<div class="col-lg-3 col-md-4 col-sm-6">
			<img src="img/pi.jpg" class="img-fluid pb-1"> </div>
			
			<div class="col-lg-3 col-md-4 col-sm-6">
			<img src="img/blk.jpg" class="img-fluid pb-1"> </div>
			<div class="col-lg-3 col-md-4 col-sm-6">
			<img src="img/hit.jpg" class="img-fluid pb-1"> </div>
			<div class="col-lg-3 col-md-4 col-sm-6">
			<a href="hot/index.php"><video class="img-fluid pb-1" src="first.mp4" autoplay="" controlslist="" playsinline="" loop=""  muted=""></video></a></div>
			<div class="col-lg-3 col-md-4 col-sm-6">
			<img class="jig" src="img/pim.jpg" class="img-fluid pb-1"> </div>
			
			
			
		</div>
	</div>
	
	<script src="index.js" type="text/javascript"></script>
</body>
</html>